import { useState } from "react"
import Axios from "axios"
import { useNavigate } from "react-router-dom"
const RegisterUser = () => {
    const navigate = useNavigate();
    const [username, setUsername] = useState("")
    const [password, setPassword] = useState("")
    const [name, setName] = useState("")
    const [email, setEmail] = useState("")
    const [phone, setPhone] = useState("")
    const submitFrom = async (e) => {
        e.preventDefault()
        try {
            const { data } = await Axios.post("http://localhost:7002/api/users/register",
                {
                    username, password, name, email, phone
                }
            )
            navigate('/users/login')
        }
        catch {
            alert("Invalid name, please try to enter another name")
        }


    }
    return <>
        <form className="allRegister" onSubmit={submitFrom}>

            <input
            className="inputRegister"
                value={username}
                required={true}
                placeholder="Please enter userName"
                onChange={(e) => setUsername(e.target.value)} />

            <input
            className="inputRegister"
                value={password}
                required={true}
                type="password"
                placeholder="Please enter password"
                onChange={(e) => setPassword(e.target.value)} />

            <input
            className="inputRegister"
                value={name}
                required={true}
                placeholder="Please enter name"
                onChange={(e) => setName(e.target.value)} />

            <input
            className="inputRegister"
                value={email}
                type="email"
                placeholder="Please enter email"
                onChange={(e) => setEmail(e.target.value)} />

            <input
            className="inputRegister"
                value={phone}
                placeholder="Please enter phone"
                type="number"
                onChange={(e) => setPhone(e.target.value)} />
            <button className="sendRegister" type="submit">Send</button>

        </form>
    </>
}
export default RegisterUser