import { useState } from "react"
import Axios from "axios"
import { useNavigate } from "react-router-dom"
const LoginUser = () => {
    const navigate = useNavigate();
    const [username, setUsername] = useState("")
    const [password, setPassword] = useState("")
    const submitFrom = async (e) => {
        try{
            e.preventDefault()
        const { data } = await Axios.post("http://localhost:7002/api/users/login",
            {
                username, password
            }
        )
        localStorage.setItem("userToken",data)
        navigate('/products/userProducts')        
        }
        catch(error){
            alert("Oops, the password is incorrect or you are not a registered user")
        }       
    }
    return <>
    
        <form className="allRegister" onSubmit={submitFrom}>
            <input 
            className="inputRegister"
                value={username}
                placeholder="Please enter userName"
                required={true}
                onChange={(e) => setUsername(e.target.value)} />
            <input
            className="inputRegister"
                value={password}
                placeholder="Please enter password"
                required={true}
                type="password"
                onChange={(e) => setPassword(e.target.value)} />
            <button className="sendRegister" type="submit">Send</button>       
        </form>        
    </>
}
export default LoginUser