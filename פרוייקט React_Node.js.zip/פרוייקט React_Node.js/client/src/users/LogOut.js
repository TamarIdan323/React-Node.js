import { useEffect } from "react"
import { useNavigate } from "react-router-dom"

const LogOut = () => {
    const navigate=useNavigate()
    
    useEffect(() => {
        localStorage.clear("userToken")
        navigate("/users/login")
    }, [])
    return(
        <></>
    )
}

export default LogOut