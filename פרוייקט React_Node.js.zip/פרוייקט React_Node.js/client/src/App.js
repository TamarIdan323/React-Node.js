import './App.css';
import { BrowserRouter as Router, Routes, Route } from "react-router-dom"
import RegisterUser from './users/RegisterUser';
import Layout from './common/Layout';
import LoginUser from './users/LoginUser';
import LogOut from './users/LogOut';
import UserProducts from './products/UserProducts';
import AdminProduct from './products/AdminProduct';
import CreateProduct from './products/CreateProduct';
import DeleteProduct from './products/DeleteProduct';
import UpdateProduct from './products/UpdateProduct';
import ShoppingCart from './shopingCart/ShoppingCart';
function App() {
  return (
    <div className="App">
      <Router>
        <Routes>
          <Route path='/' element={<Layout />}>
            <Route index element={<h1><br></br><br></br>Welcome to our website<br></br><br></br>
              We, the "Watch Wave" company, make quality watches for you<br></br><br></br>
              Feel free to take a look at our watches and also buy 😄</h1>} />
            <Route path='/users/register' element={<RegisterUser />} />
            <Route path='/users/login' element={<LoginUser />} />
            <Route path='/users/logOut' element={<LogOut />} />
            <Route path='/products/userProducts' element={<UserProducts />} />
            <Route path='/products/AdminProduct' element={<AdminProduct />} />
            <Route path='/products/CreateProduct' element={<CreateProduct />} />
            <Route path='/products/DeleteProduct' element={<DeleteProduct />} />
            <Route path='/products/UpdateProduct' element={<UpdateProduct />} />
            <Route path='/users/shoppingcart' element={<ShoppingCart />} />
          </Route>
        </Routes>
      </Router>
    </div>
  );
}

export default App;
