import { Link, Outlet } from "react-router-dom"
import { MdOutlineAddIcCall } from "react-icons/md";
import { MdEmail } from "react-icons/md";
import { MdOutlineWhatsapp } from "react-icons/md";
const Layout = () => {
    return <div className="page">

        <header className="allLinks">
            <img src={`/pic/logo.jpg`} alt={"not founded 🤭🙈"} className="logo" />
            <Link className="aLink" to="/">home page</Link>&nbsp;&nbsp;
            <Link className="aLink" to="/users/register">register</Link>&nbsp;&nbsp;
            <Link className="aLink" to="/users/login">login</Link>&nbsp;&nbsp;
            <Link className="aLink" to="/products/userProducts">products</Link>&nbsp;&nbsp;
            <Link className="aLink" to="/products/AdminProduct">product management</Link>&nbsp;&nbsp;
            <Link className="aLink" to="/users/logOut">logOut</Link>&nbsp;&nbsp;
            <Link className="aLink" to="/users/shoppingcart">shopping cart</Link>
            <br></br><br></br>
        </header>
        <main>
            <Outlet />

        </main>
        <footer className="afooter">
            <div className="AboutUs">
                <div className="AboutUsInfo">
                    Our Stors:<br></br><br></br>
                    &nbsp;&nbsp;*&nbsp;&nbsp;Jerusalem<br></br>
                    *&nbsp;&nbsp;Herzliya<br></br>
                    *&nbsp;&nbsp;Tel-Aviv
                </div>
                <div className="AboutUsInfo">
                    Opening Hours:<br></br><br></br>
                    Sunday-Thursday: 10:00-22:00
                </div>
                <div className="AboutUsInfo">
                    Contact:<br></br><br></br>
                    <MdEmail />&nbsp;&nbsp;Email: WatchWave@gmail.com<br></br>
                    <MdOutlineWhatsapp />&nbsp;&nbsp;WhatsApp:055-3234382<br></br>
                    <MdOutlineAddIcCall />&nbsp;&nbsp;Phone: 0583257887

                </div>
            </div>
            <div className="kolHazchuyot">
                © &nbsp;This website was developed by: &nbsp;
                Pazit Idan & Nadine Manes
            </div>
        </footer>
    </div>
}
export default Layout