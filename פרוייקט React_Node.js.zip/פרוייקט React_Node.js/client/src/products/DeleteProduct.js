import Axios from "axios"
import { useNavigate } from "react-router-dom"
import { MdDelete } from "react-icons/md";
const DeleteProduct = ({ product, getAllProducts }) => {
    const navigate = useNavigate();
    const deletProduct = async () => {
        try {
            const { data } = await Axios.delete("http://localhost:7002/api/products",
                {
                    data: { id: product._id },
                    headers: { 'Authorization': `Bearer ${localStorage.getItem("userToken")}` }
                }
            )
            getAllProducts()
        }
        catch {
            alert("Reset An error occurred while deleting the product, please try deleting again");
        }
    }
    const updateProduct = () => {
        navigate('/products/UpdateProduct', { state: product })
    }
    return (
        <div className="product-card">
            <img src={`/pic/${product.productImage}`} alt={product.mnufacturer} className="product-image" />
            <h2 className="product-manufacturer">{product.mnufacturer}</h2>
            <h2 className="product-price">{product.productPrice}</h2>
            <div className="button-container">
                <button onClick={deletProduct} className="product-button delete-button"><MdDelete /></button>
                <button onClick={updateProduct} className="product-button update-button">Update</button>
            </div>
        </div>
    )
}
export default DeleteProduct