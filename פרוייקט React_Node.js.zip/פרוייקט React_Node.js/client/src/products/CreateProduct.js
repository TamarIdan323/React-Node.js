import { useState } from "react"
import Axios from "axios"
import { useNavigate } from "react-router-dom"
const CreateProduct = () => {
    const navigate=useNavigate()
    const [productId, setProductId] = useState("")
    const [productType, setProductType] = useState("Digital")
    const [mnufacturer, setMnufacturer] = useState("")
    const [productPrice, setProductPrice] = useState("")
    const [productColor, setProductColor] = useState("")
    const [productImage, setProductImage] = useState("")
    const submitFrom = async (e) => {
        e.preventDefault()
        try{const { data } = await Axios.post("http://localhost:7002/api/products",
            {
                productId, productType, mnufacturer, productPrice, productColor, productImage,
                
            },{headers: { 'Authorization': `Bearer ${localStorage.getItem("userToken")}`} }
            
        )
        alert("product created")
        navigate('/products/AdminProduct')

    }
    catch{
        alert("Oops an error occurred while creating a new product, if you are an existing user we apologize for the error, please try creating again. If you are not an existing user - sorry but you cannot create products for us, you must register. Hoping for understanding")
    }
    }
    return <>
        <form className="allRegister"  onSubmit={submitFrom}>

            <input
            className="inputRegister"
                value={productId}
                required={true}
                type="number"
                placeholder="Please enter productId"
                onChange={(e) => setProductId(e.target.value)} />

            <select
            className="inputRegister"
                value={productType}
                onChange={(e) => setProductType(e.target.value)} >
                    <option>Digital</option>
                    <option>Analog</option>
                </select>

            <input
            className="inputRegister"
                value={mnufacturer}
                required={true}
                placeholder="Please enter mnufacturer"
                onChange={(e) => setMnufacturer(e.target.value)} />

            <input
            className="inputRegister"
                value={productPrice}
                required={true}
                type="number"
                placeholder="Please enter productPrice"
                onChange={(e) => setProductPrice(e.target.value)} />

            <input
            className="inputRegister"
                value={productColor}
                required={true}
                placeholder="Please enter productColor"
                onChange={(e) => setProductColor(e.target.value)} />

            <input
            className="inputRegister"
                value={productImage}
                placeholder="Please enter productImage"
                onChange={(e) => setProductImage(e.target.value)} />
            <button className="sendRegister" type="submit">Add</button>

        </form>
    </>
}
export default CreateProduct