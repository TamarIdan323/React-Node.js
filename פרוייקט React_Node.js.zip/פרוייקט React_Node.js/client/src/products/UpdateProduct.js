import { useState } from "react"
import Axios from "axios"
import { useLocation } from "react-router-dom"
import { useNavigate } from "react-router-dom"
const UpdateProduct = () => {
    const navigate = useNavigate()
    const location = useLocation();
    const p = location.state
    const [id, setId] = useState(p._id)
    const [productId, setProductId] = useState(p.productId)
    const [productType, setProductType] = useState(p.productType)
    const [mnufacturer, setMnufacturer] = useState(p.mnufacturer)
    const [productPrice, setProductPrice] = useState(p.productPrice)
    const [productColor, setProductColor] = useState(p.productColor)
    const [productImage, setProductImage] = useState(p.productImage)
    const submitFrom = async (e) => {
        e.preventDefault()
        try {
            const { data } = await Axios.put("http://localhost:7002/api/products",
                {
                    id, productId, productType, mnufacturer, productPrice, productColor, productImage
                }, { headers: { 'Authorization': `Bearer ${localStorage.getItem("userToken")}` } }
            )
            alert("product updated");
            navigate('/products/AdminProduct')
        }
        catch {
            alert("Oops, an error occurred during a product update. If you are an existing user we apologize for the error, please try updating again. If you are not an existing user - sorry but you cannot update us products, you must register. Hoping for understanding");
        }
    }
    return (
        <form className="allRegister" onSubmit={submitFrom}>
            <input
            className="inputRegister"
                value={productId}
                required={true}
                type="number"
                placeholder={productId}
                onChange={(e) => setProductId(e.target.value)} />

            <select
            className="inputRegister"
                value={productType}
                onChange={(e) => setProductType(e.target.value)} >
                <option>Digital</option>
                <option>Analog</option>
            </select>

            <input
            className="inputRegister"
                value={mnufacturer}
                placeholder={mnufacturer}
                onChange={(e) => setMnufacturer(e.target.value)} />

            <input
            className="inputRegister"
                value={productPrice}
                required={true}
                type="number"
                placeholder={productPrice}
                onChange={(e) => setProductPrice(e.target.value)} />

            <input
            className="inputRegister"
                value={productColor}
                required={true}
                placeholder="enter productColor"
                onChange={(e) => setProductColor(e.target.value)} />

            <input
            className="inputRegister"
                value={productImage}
                placeholder={productColor}
                onChange={(e) => setProductImage(e.target.value)} />
            <button className="sendRegister" type="submit">update</button>
        </form>
    )
}
export default UpdateProduct