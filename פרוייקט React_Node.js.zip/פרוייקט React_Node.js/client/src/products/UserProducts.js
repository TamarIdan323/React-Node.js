import { useEffect, useState } from "react"
import Axios from "axios"
import { MdAddShoppingCart } from "react-icons/md";
import { MdOutlineWallpaper } from "react-icons/md";
const UserProducts = () => {
    const [products, setProducts] = useState([])
    const getAllProducts = async () => {
        try {
            const { data } = await Axios.get("http://localhost:7002/api/products")
            setProducts(data)
        }
        catch (error) {
            alert("Oops, there was a system error, the product are not available")
        }
    }
    useEffect(() => {
        getAllProducts()
    }, [])

    const AddToShoppingCart = async (p) => {
        try {
            const { data } = await Axios.post("http://localhost:7002/api/shoppingCarts",
                { product: p._id },
                { headers: { 'Authorization': `Bearer ${localStorage.getItem("userToken")}` } }
            )
            alert("wow , added to cart succeffuly")
        }
        catch (error) {
            alert("oop,error adding to cart please try agian")
        }
    }
    return (
        <div className="allProducts">
            {products.map((p, index) => (
                <div className="product" key={index}>
                    <img src={`/pic/${p.productImage}`} alt={"not founded 🤭🙈"} className="imageProduct" />
                    <div className="typeAndManufacturer">
                        <h2>{p.productType}</h2>
                        <h3>{p.mnufacturer}</h3>
                    </div>
                    <div className="priceAndButton">
                        <h2 className="priceProduct">₪{p.productPrice}</h2>
                        <button type="button" onClick={() => AddToShoppingCart(p)} className="submitProduct"><MdAddShoppingCart /></button>
                    </div>
                </div>
            ))}
        </div>
    );
};
export default UserProducts