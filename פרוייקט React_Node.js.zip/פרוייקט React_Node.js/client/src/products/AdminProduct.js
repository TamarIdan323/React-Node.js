import { useEffect, useState } from "react"
import Axios from "axios"
import { MdOutlineAddTask } from "react-icons/md";
import DeleteProduct from "./DeleteProduct"
import { Link } from "react-router-dom"
const AdminProduct = () => {
    const [products, setProducts] = useState([])
    const getAllProducts = async () => {
        try {
            const { data } = await Axios.get("http://localhost:7002/api/products")
            setProducts(data)
        }
        catch (error) {
            alert("Oops, there was a system error, the data is not available")
        }
    }
    useEffect(() => {
        getAllProducts()
    }, [])
    return (
        <>
            <div>
                <Link className="linkcreatproduct" to="/products/CreateProduct">add new product&nbsp;<MdOutlineAddTask /></Link>
            </div>
            <div className="allProducts" >
                {products.map((p, index) => (
                    <DeleteProduct key={index} product={p} getAllProducts={getAllProducts} />
                ))}
            </div>
        </>
    )
}
export default AdminProduct