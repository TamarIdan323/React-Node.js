import { useEffect, useState } from "react";
import Axios from "axios";
import { MdDelete } from "react-icons/md";
const ShoppingCart = () => {
    const [products, setProducts] = useState([]);

    const gotoshoppingcart = async () => {
        try {
            const { data } = await Axios.get("http://localhost:7002/api/shoppingCarts", {
                headers: { 'Authorization': `Bearer ${localStorage.getItem("userToken")}` }
            });
            setProducts(data);
        }
        catch (error) {
        }
    };

    const deletProductFromShoppingCart = async (p) => {
        try {
            const { data } = await Axios.delete("http://localhost:7002/api/shoppingCarts",
                {
                    data: { id: p._id },
                    headers: { 'Authorization': `Bearer ${localStorage.getItem("userToken")}` }
                }
            )
            gotoshoppingcart();
        }
        catch {
            alert("Reset An error occurred while deleting the product, please try deleting again");
        }
    }

    useEffect(() => {
        gotoshoppingcart();
    }, []);

    return (
        <div className="shopping-containerr">
            {products.map((p, index) => (
                <div key={index} className="product-cardd">
                    <img src={`/pic/${p.productImage}`} alt="אין תמונה" className="product-imagee" />
                    <div className="product-infoo">
                        <h2 className="product-manufacturerr">{p.mnufacturer}</h2>
                        <h3 className="product-pricee">{p.productPrice} ₪</h3>
                    </div>
                    <button onClick={() => deletProductFromShoppingCart(p)} className="delete-btnn"><MdDelete />&nbsp;&nbsp;Remove from cart</button>
                </div>
            ))}
        </div>
    );
};

export default ShoppingCart;
