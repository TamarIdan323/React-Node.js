const mongoose = require("mongoose")
const Schema = mongoose.Schema 
const productSchema = new Schema({
    productId:{ 
        type: String,
        required: true,
        lowercase: true,
        trim: true
    },
    productType: {
        type: String,
        enum: ['Digital', 'Analog'],
        default: "Analog",
    },
    mnufacturer:{ 
        type: String,
        required: true
    },
    productPrice:{ 
        type: Number,
        required: true
    },
    productColor:{ 
        type: String,
        required: true
    },
    productImage:{ 
        type: String,
    }
},{ timestamps: true })
module.exports = mongoose.model("Product", productSchema)