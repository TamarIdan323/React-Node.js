const Product=require("../models/Product")

const creatProduct=async(req,res) =>{
    const {productId, productType, mnufacturer,productPrice,productColor,productImage}=req.body
    const product = await Product.create({
        productId, productType, mnufacturer,productPrice,productColor,productImage
    })
    res.json(product)
}
const getProductById=async(req,res)=>{
    const {id}=req.body
    const product=await Product.findById(id)
    if(!product){
        return res.status(400).json({ message: 'product not found' })
    }
    res.json(product)
}
const getAllProduct=async(req,res)=>{
    const products = await Product.find()
    res.json(products)
}

const updateProduct= async(req,res)=>{
    const{id, productId, productType, mnufacturer,productPrice,productColor,productImage}=req.body
    if(!id){
        return res.send("No such id")
    }
    const product = await Product.findById(id)
    if(!product){
        return res.send("No such id")
    }
    product.productId=productId
    product.productType=productType
    product.mnufacturer=mnufacturer
    product.mnufacturer=mnufacturer
    product.productPrice=productPrice
    product.productPrice=productPrice
    product.productColor=productColor
    product.productImage=productImage
    const updatedProduct = await product.save()
    res.json("product updated")
}

const deleteProduct= async (req,res)=>{
    const { id } = req.body
    const product = await Product.findById(id)
    if (!product) {
        return res.send("No such id")
    }
    const result = await product.deleteOne()
    const reply = `Product deleted`
    res.json(reply)
}

module.exports = {creatProduct, getAllProduct,getProductById,updateProduct,deleteProduct}





