const ShoppingCart = require("../models/ShoppingCart")
const Product = require("../models/Product")

const creatShoppingCart = async (req, res) => {
    const { product } = req.body

    if (!product) {
        return res.status(400).json({ message: 'productid is required' })
    }
    const shoppingCart = await ShoppingCart.create({
        user: req.user._id, product
    })
    if (shoppingCart) {
        return res.status(201).json({ message: 'New shoppingCart created' })
    } else {
        return res.status(400).json({ message: 'Invalid shoppingCart ' })
    }
}

const getAllShoppingCart = async (req, res) => {
    const userId = req.user._id;
    const shoppingCart = await ShoppingCart.find({ user: userId });
    const arrid = shoppingCart.map((p) => p.product._id); 
    let newarr = [];
    await Promise.all(arrid.map(async (item) => {
        const prod = await Product.findById(item);
        if (prod) newarr.push(prod);
    }));
    res.json(newarr);
};

const updateShoppingCart = async (req, res) => {
    const { id, user, product } = req.body
    if (!id) {
        return res.send("No such id")
    }
    const shoppingCart = await ShoppingCart.findById(id)
    if (!shoppingCart) {
        return res.send("No such id")
    }
    shoppingCart.user = user,
        shoppingCart.product = product
    const updatedShoppingCart = await shoppingCart.save()
    res.json("shoppingCart updated")
}

const deleteShoppingCart = async (req, res) => {
    const { id } = req.body
    const shoppingCart = await ShoppingCart.findOne({product:id})
    if (!shoppingCart) {
        return res.send("No such task")
    }
    const result = await shoppingCart.deleteOne()
    const reply = `ShoppingCart deleted`
    res.json(reply)
}

module.exports = { creatShoppingCart, getAllShoppingCart, updateShoppingCart, deleteShoppingCart }