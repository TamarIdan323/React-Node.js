const express = require("express")
const verifyJWT = require("../middleware/verifyJWT")
const router = express.Router()
const ShoppingCart=require("../controllers/ShoppingCartController")

router.use(verifyJWT)

router.post("/",ShoppingCart.creatShoppingCart)
router.get("/", ShoppingCart.getAllShoppingCart)
router.put("/",ShoppingCart.updateShoppingCart)
router.delete("/",ShoppingCart.deleteShoppingCart)

module.exports = router